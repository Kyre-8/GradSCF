"""Bound one single-process scientific calculation; imported by launch commands."""
import json
import sys
from pathlib import Path

from rss_budget import monitor


def run(name, scientific_code):
    report = monitor([sys.executable, '-u', '-c', scientific_code], 64*1024**2)
    destination = Path('artifacts/fft71')/(name+'_resource_budget.json')
    destination.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2), flush=True)
    raise SystemExit(1 if report['budget_exceeded'] else report['return_code'])
