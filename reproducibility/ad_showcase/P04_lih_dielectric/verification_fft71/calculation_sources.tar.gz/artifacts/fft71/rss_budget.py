"""One final native k8 case, monitored against the agreed 120 GiB RSS budget."""
import json
import resource
import subprocess
import sys
import time
from pathlib import Path


def monitor(command, budget_kib):
    """One child in a fresh wrapper process, including its complete exit usage."""
    child = subprocess.Popen(command)
    peak = 0
    exceeded = False
    while child.poll() is None:
        try:
            status = Path(f'/proc/{child.pid}/status').read_text().splitlines()
            high_water = next(int(line.split()[1]) for line in status if line.startswith('VmHWM:'))
            peak = max(peak, high_water)
            if high_water > budget_kib:
                exceeded = True
                child.terminate()
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait()
                break
        except (FileNotFoundError, ProcessLookupError, StopIteration):
            # Exiting/zombie children can still have a status file without RSS.
            pass
        time.sleep(.25)
    code = child.wait()
    peak = max(peak, resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    exceeded |= peak > budget_kib
    return dict(command=command, return_code=code, peak_rss_kib=peak,
                budget_kib=budget_kib, budget_exceeded=exceeded,
                polling_seconds=.25, accepted=code == 0 and not exceeded)


if __name__ == '__main__':
    command = [sys.executable, '-u', '-c',
        "from examples.pbc.lih_forces_stress import SETTINGS,run_case; "
        "run_case('pbe_szv_k8_fft31',dict(SETTINGS,kmesh=[8]*3))"]
    report = monitor(command, 120*1024**2)
    folder = Path('reproducibility/ad_showcase/P01_P02_lih_periodic')
    (folder/'k8_resource_budget.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2), flush=True)
    raise SystemExit(1 if report['budget_exceeded'] else report['return_code'])
