"""Zero-field Berry polarization response to periodic atomic displacements.

This first adapter supplies dP/dR and hence Born charges. It does not supply
a uniform electric field, dielectric response or a finite-field SCF algorithm.
"""
import jax
import jax.numpy as jnp
import numpy as np

from .core import Problem
from .periodic import periodic_problem
from ..integrals.periodic.fft import build_inputs
from ..pbc.polarization import make_plan, ao_links, occupied_frame, polarization, _berry
from ..pbc.scf import validate_reference


def born_problem(source, *, tolerance=1e-8, gap_tol=1e-8, link_tol=1e-8):
    """Return a fixed-cell geometry Problem observing total P in e/bohr^2.

    response(tangent=dR).values['polarization'] is the relaxed directional
    dP/dR. Multiplication by cell volume gives the Born-charge contraction in
    units of e. The coordinates are Cartesian Bohr, the lattice/FFT topology,
    basis exponents and full equal-weight k mesh are fixed. Every explicit spin
    channel has integer unit occupations and an insulating indirect gap.

    The existing KS projector residual supplies density response. A local
    Cholesky frame and moving cross-k AO links supply the Berry derivative;
    canonical orbital eigenvectors are never differentiated. Reference phases
    anchor the local branch even when the principal forward phase is at pi.
    Build a fresh problem after changing the reference. Only first geometry
    response is certified by this adapter; Taylor/mixed field response is absent.
    """
    if getattr(source, 'temperature', None) is not None:
        raise NotImplementedError('Born response currently requires zero temperature.')
    validate_reference(source, integer=True, equal_weights=True, external=True)
    cell = source.cell
    counts = tuple(int(n) for n in cell.nelec)
    fractional = np.asarray(source.kpts)@np.asarray(cell.lattice).T/(2*np.pi)
    plan = make_plan(fractional, kweights=source.kweights)
    reference = polarization(source.inputs, source.result, plan, nocc=counts,
                             tolerance=tolerance, gap_tol=gap_tol, link_tol=link_tol)
    anchor = jax.tree.map(jax.lax.stop_gradient, reference.phases)
    base = periodic_problem(source.inputs, source.result, mesh=cell.mesh, nelec=counts,
        xc=source.xc, exxdiv=source.exxdiv, functional=source.functional,
        params=source.params, tolerance=tolerance)
    reference_frames = tuple(source.result.mo_coeff_spin[spin, :, :, :n] for spin, n in enumerate(counts))

    def args_at(coordinates):
        data = build_inputs(cell, parameters=cell.parameters_at(coordinates),
                            kpts=source.kpts, kweights=source.kweights)
        return (data._replace(hcore=data.hcore.astype(jnp.complex128)),)+base.inputs[1:]

    def quantities(state, coordinates):
        args = args_at(coordinates)
        data = args[0]
        values = base.quantities(state, args)
        density = values['density']
        frames = tuple(occupied_frame(density[spin], data.overlap, ref, tolerance=tolerance).coefficients
                       for spin, ref in enumerate(reference_frames))
        links = ao_links(data.ao, data.weights, data.coords, data.lattice, plan)
        berry = _berry(frames, links, data.lattice, plan, reference_phases=anchor, link_tol=link_tol)
        ionic = data.ionic_charges@data.atom_coords/jnp.linalg.det(data.lattice)
        return dict(values, polarization=berry.electronic+ionic)

    return Problem(lambda state,r:base.residual(state, args_at(r)), base.solution,
                   cell.coords, quantities, base.converged & reference.valid,
                   tolerance, series_supported=False)


__all__ = ['born_problem']
